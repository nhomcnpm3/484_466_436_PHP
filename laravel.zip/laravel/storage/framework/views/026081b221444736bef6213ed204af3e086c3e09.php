    <div class="container-fluid">
      <div class="container">
        <hr>
        <footer>
          © 2007 - 2016 Công Ty Cổ Phần Bán Lẻ Kỹ Thuật Số FSHOP / Địa chỉ: TP. BMT / GPĐKKD số: Websitr đang thử nghiệm. <br>
          Thiết Kế Bởi : <a href="https://www.facebook.com/vietdhtn" title="" target="#">Hoàng Việt</a>
      </footer>
      </div>
    </div>
    <a id="back-to-top" href="#" class="btn btn-warning btn-lg back-to-top" role="button" title="Click lên đâu trang" data-toggle="tooltip" data-placement="left"><span class="glyphicon glyphicon-chevron-up"></span></a>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="<?php echo url('bootstrap/js/bootstrap.min.js'); ?>"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <?php /* <script src="<?php echo url('bootstrap/js/ie10-viewport-bug-workaround.js'); ?>"></script> */ ?>
    <!-- menu js -->
    <script src="<?php echo url('js/menu.js'); ?>"></script> 
    <script type='text/javascript' src='<?php echo url('js/jquery.easing.1.3.js'); ?>'></script> 
    <script type='text/javascript' src='<?php echo url('js/camera.min.js'); ?>'></script> 
    <script type='text/javascript' src='<?php echo url('js/myscript.js'); ?>'></script> 
    <script type='text/javascript' src='<?php echo url('js/active-menu.js'); ?>'></script> 
    <script src="<?php echo url('js/bootstrap-image-gallery.min.js'); ?>"></script>
    <script src="<?php echo url('js/jquery.blueimp-gallery.min.js'); ?>"></script>

    <?php /* validate */ ?>
    <script src="<?php echo url('js/validate/jquery.validate.min.js'); ?>"></script>
    <script src="<?php echo url('js/validate/jquery.validate.js'); ?>"></script>

  </body>
</html>