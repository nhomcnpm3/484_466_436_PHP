<?php $__env->startSection('content'); ?>
	<div class="table-responsive">
		<table class="table table-bordered table-hover text-center">
			<thead>
				<tr>
					<th colspan="2">Thông tin chi tiết của khách hàng : <?php echo Auth::user()->name; ?></th>										
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>Họ tên</td>
					<td><?php echo Auth::user()->name; ?></td>
				</tr>
				<tr>
					<td>Địa chỉ E-mail</td>
					<td><?php echo Auth::user()->email; ?></td>
				</tr>
				<tr>
					<td>Điện thoại</td>
					<td><?php echo Auth::user()->phone; ?></td>
				</tr>
				<tr>
					<td>Địa chỉ Khách hàng</td>
					<td><?php echo Auth::user()->address; ?></td>
				</tr>
				<tr>
					<td>Ngày đăng ký</td>
					<td><?php echo Auth::user()->created_at; ?></td>
				</tr>
			</tbody>
		</table>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>