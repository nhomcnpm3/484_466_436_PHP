 <!-- slider event - top -->
<div class="container hidden-xs">
    <div class="fluid_container">            
      <div class="camera_violet_skin" id="camera_wrap_1">
        <div data-thumb="<?php echo url('public/images/slides/thumbs/qc1.png'); ?>" data-src="<?php echo url('public/images/slides/thumbs/qc1.png'); ?>">
            <div class="camera_caption fadeFromBottom">
                Sắm Apple giá tốt, Du lịch châu âu. <em>Event mua hàng Apple Tại Thế Giới Di Động</em>
            </div>
        </div>
        <div data-thumb="<?php echo url('public/images/slides/thumbs/qc2.png'); ?>" data-src="<?php echo url('public/images/slides/thumbs/qc2.png'); ?>">
            <div class="camera_caption fadeFromBottom">
                Sony trả góp 0%, có cỏ hội trúng Tivi 4K <em> Dành cho sản phẩm sony Tại Thế Giới Di Động </em>
            </div>
        </div>
        <div data-thumb="<?php echo url('public/images/slides/thumbs/qc3.png'); ?>" data-src="<?php echo url('public/images/slides/thumbs/qc3.png'); ?>">
            <div class="camera_caption fadeFromBottom">
                Galaxy J7 Prime - mua online thêm quà, <em> Dành cho Galaxy J7 Prime Tại Thế Giới Di Động </em>
            </div>
        </div>
        <div  data-thumb="<?php echo url('public/images/slides/thumbs/qc4.png'); ?>" data-src="<?php echo url('public/images/slides/thumbs/qc4.png'); ?>">
            <div class="camera_caption fadeFromBottom">
                Galaxy J7 Prime - mua online thêm quà, <em> Dành cho Galaxy J7 Prime Tại Thế Giới Di Động </em>
            </div>
        </div>
        <div data-thumb="<?php echo url('public/images/slides/thumbs/qc5.png'); ?>" data-src="<?php echo url('public/images/slides/thumbs/qc5.png'); ?>">
            <div class="camera_caption fadeFromBottom">
                 Galaxy J7 Prime - mua online thêm quà, <em> Dành cho Galaxy J7 Prime Tại Thế Giới Di Động </em>)
            </div>
        </div>
        <div data-thumb="<?php echo url('public/images/slides/thumbs/qc6.jpg'); ?>" data-src="<?php echo url('public/images/slides/thumbs/qc6.jpg'); ?>">
            <div class="camera_caption fadeFromBottom">
               Đồng hành cùng lễ hội Hàn Quốc   <em> Khuyễn mãi tại siêu thị Nguyễn Kim</em>
            </div>
        </div>
      </div><!-- #camera_wrap_1 -->       
    </div><!-- .fluid_container -->   
</div> <!-- /slider event - top -->