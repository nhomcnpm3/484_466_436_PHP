<?php $__env->startSection('content'); ?>
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
 <!-- ====================================== /loc ket qua theo lua chon================================= -->
      <div id="pc"></div>
        <?php foreach($data as $row): ?>
           <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 no-padding">
            <div class="thumbnail pc">              
              <div class="bt">
                <div class="image-m pull-left">
                  <img class="img-responsive" src="<?php echo url('uploads/products/'.$row->images); ?>" alt="<?php echo $row->name; ?>">
                </div>
                <div class="intro pull-right">
                  <h1><small class="title-pc"><?php echo $row->name; ?></small></h1>
                  <li>Cpu: <?php echo $row->cpu; ?> </li>
                  <li><?php echo $row->ram; ?></li>
                  <li>HDD : <?php echo $row->storage; ?> </li>
                  <span class="label label-info">Khuyễn mãi</span>   
                  <?php if($row->promo1!=''): ?>
                    <li><span class="glyphicon glyphicon-ok-sign"></span><?php echo $row->promo1; ?></li>
                  <?php elseif($row->promo2!=''): ?>
                    <li><span class="glyphicon glyphicon-ok-sign"></span><?php echo $row->promo2; ?></li>
                  <?php elseif($row->promo3!=''): ?>
                    <li><span class="glyphicon glyphicon-ok-sign"></span><?php echo $row->promo3; ?></li>
                  <?php endif; ?> 
                    <li><span class="glyphicon glyphicon-ok-sign"></span>Cài đặt phần miềm, tải nhạc - ứng dụng miến phí</li>
                </div><!-- /div introl -->
              </div> <!-- /div bt -->
              <div class="ct">
                <a href="<?php echo url('pc/'.$row->id.'-'.$row->slug); ?> title="Chi tiết">                   
                  <span class="label label-warning">Cấu hình chi tiết</span> 
                  <li><strong>Mainboard</strong> : <i>  <?php echo $row->screen; ?></i></li>
                  <li><strong>CPU</strong> : <i>  <?php echo $row->cpu; ?></i></li>
                  <li><strong>HDD</strong> : T<i><?php echo $row->storage; ?> </i></li> 
                  <li><strong>HĐH</strong> :<i><?php echo $row->os; ?>  </i> - <strong>RAM </strong> :<i><?php echo $row->ram; ?></i></li> 
                  <li><strong>VGA </strong> :<i> <?php echo $row->vga; ?></i></li>
                  <li><strong>Kết nối</strong> : <i> <?php echo $row->connect; ?></i></li> 
                </a>
              </div>
                <span class="btn label-warning"><strong><?php echo number_format($row->price); ?></strong> Vnd </span>
                <a href="<?php echo url('gio-hang/addcart/'.$row->id); ?>" class="btn btn-success pull-right add">Thêm vào giỏ </a>
            </div> <!-- / div thumbnail -->
          </div>  <!-- /div col-4 item products -->
        <?php endforeach; ?>
      <div class="clearfix">
        
      </div>
      <!-- ===================================================================================/products ============================== -->
      <?php echo $data->render();; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.new-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>