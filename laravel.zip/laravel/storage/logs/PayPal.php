[17-12-2016 08:53:45] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 08:53:46] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 08:53:47] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 08:53:47] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 08:53:48] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 08:53:49] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 08:54:26] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 08:54:26] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 08:54:27] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 08:54:27] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 08:54:28] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 08:54:29] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 08:54:44] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 08:54:44] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 08:54:45] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 08:54:45] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 08:54:46] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 08:54:47] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 08:55:13] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 08:55:14] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 08:55:15] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 08:55:15] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 08:55:15] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 08:55:17] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 08:55:56] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 08:55:56] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 08:55:57] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 08:55:57] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 08:55:58] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 08:55:59] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 09:05:30] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 09:05:30] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:05:33] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:05:33] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 09:05:34] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:05:35] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 09:05:49] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 09:05:50] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:05:51] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:05:51] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 09:05:51] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:05:53] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 09:06:39] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 09:06:39] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:06:40] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:06:40] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 09:06:41] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:06:42] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 09:22:44] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 09:22:45] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:22:46] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:22:46] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 09:22:46] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:22:48] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 09:27:44] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 09:27:44] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:27:45] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:27:45] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 09:27:46] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:27:47] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 09:34:54] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 09:34:55] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:34:56] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:34:56] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 09:34:56] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:34:58] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 09:35:13] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 09:35:14] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:35:15] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:35:15] PayPal\Core\PayPalHttpConnection : INFO: GET https://api.sandbox.paypal.com/v1/payments/payment/PAY-9B914912BR608342BLBKQNQQ
[17-12-2016 09:35:15] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:35:16] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:35:17] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment/PAY-9B914912BR608342BLBKQNQQ/execute
[17-12-2016 09:35:17] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:35:19] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:38:00] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 09:38:00] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:38:01] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:38:01] PayPal\Core\PayPalHttpConnection : INFO: GET https://api.sandbox.paypal.com/v1/payments/payment/PAY-9B914912BR608342BLBKQNQQ
[17-12-2016 09:38:02] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:38:03] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:38:03] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment/PAY-9B914912BR608342BLBKQNQQ/execute
[17-12-2016 09:38:03] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:38:04] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 400
[17-12-2016 09:38:04] PayPal\Core\PayPalHttpConnection : ERROR: Got Http response code 400 when accessing https://api.sandbox.paypal.com/v1/payments/payment/PAY-9B914912BR608342BLBKQNQQ/execute. {"name":"PAYMENT_ALREADY_DONE","message":"Payment has been done already for this cart.","information_link":"https://developer.paypal.com/docs/api/#PAYMENT_ALREADY_DONE","debug_id":"b53629dd2b61f"}
[17-12-2016 09:38:12] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 09:38:13] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:38:14] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:38:14] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 09:38:15] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:38:16] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 09:38:31] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 09:38:31] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:38:32] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:38:32] PayPal\Core\PayPalHttpConnection : INFO: GET https://api.sandbox.paypal.com/v1/payments/payment/PAY-4BB45279GS960173XLBKQPCI
[17-12-2016 09:38:33] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:38:34] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:38:34] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment/PAY-4BB45279GS960173XLBKQPCI/execute
[17-12-2016 09:38:35] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:38:37] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:46:37] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 09:46:38] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:46:39] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:46:39] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 09:46:39] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:46:40] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 09:47:22] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 09:47:22] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:47:23] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:47:23] PayPal\Core\PayPalHttpConnection : INFO: GET https://api.sandbox.paypal.com/v1/payments/payment/PAY-1FK39479TY7559152LBKQTAI
[17-12-2016 09:47:23] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:47:24] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:47:25] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment/PAY-1FK39479TY7559152LBKQTAI/execute
[17-12-2016 09:47:25] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:47:28] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:48:38] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 09:48:38] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:48:39] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:48:39] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 09:48:39] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:48:41] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 09:49:09] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 09:49:09] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:49:10] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:49:11] PayPal\Core\PayPalHttpConnection : INFO: GET https://api.sandbox.paypal.com/v1/payments/payment/PAY-8HM83830S7500271RLBKQT6I
[17-12-2016 09:49:11] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:49:12] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:49:12] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment/PAY-8HM83830S7500271RLBKQT6I/execute
[17-12-2016 09:49:13] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:49:14] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:54:12] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 09:54:12] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:54:13] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:54:13] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 09:54:14] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:54:15] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 09:54:26] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 09:54:27] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:54:28] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:54:28] PayPal\Core\PayPalHttpConnection : INFO: GET https://api.sandbox.paypal.com/v1/payments/payment/PAY-6K0042435U503984MLBKQWSA
[17-12-2016 09:54:29] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:54:30] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 09:54:30] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment/PAY-6K0042435U503984MLBKQWSA/execute
[17-12-2016 09:54:30] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 09:54:32] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:01:16] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 11:01:17] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:01:18] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:01:18] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 11:01:19] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:01:20] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 11:02:20] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 11:02:21] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:02:22] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:02:22] PayPal\Core\PayPalHttpConnection : INFO: GET https://api.sandbox.paypal.com/v1/payments/payment/PAY-8X726181MU581154CLBKRWAA
[17-12-2016 11:02:22] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:02:23] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:02:24] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment/PAY-8X726181MU581154CLBKRWAA/execute
[17-12-2016 11:02:24] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:02:26] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:03:42] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 11:03:42] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:03:43] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:03:43] PayPal\Core\PayPalHttpConnection : INFO: GET https://api.sandbox.paypal.com/v1/payments/payment/PAY-8X726181MU581154CLBKRWAA
[17-12-2016 11:03:44] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:03:45] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:03:45] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment/PAY-8X726181MU581154CLBKRWAA/execute
[17-12-2016 11:03:46] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:03:47] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 400
[17-12-2016 11:03:47] PayPal\Core\PayPalHttpConnection : ERROR: Got Http response code 400 when accessing https://api.sandbox.paypal.com/v1/payments/payment/PAY-8X726181MU581154CLBKRWAA/execute. {"name":"PAYMENT_ALREADY_DONE","message":"Payment has been done already for this cart.","information_link":"https://developer.paypal.com/docs/api/#PAYMENT_ALREADY_DONE","debug_id":"169a0d069e535"}
[17-12-2016 11:04:07] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 11:04:08] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:04:09] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:04:09] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 11:04:09] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:04:11] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 11:04:24] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 11:04:24] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:04:26] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:04:26] PayPal\Core\PayPalHttpConnection : INFO: GET https://api.sandbox.paypal.com/v1/payments/payment/PAY-56U98642P13079828LBKRXKY
[17-12-2016 11:04:26] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:04:27] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:04:27] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment/PAY-56U98642P13079828LBKRXKY/execute
[17-12-2016 11:04:28] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:04:29] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:05:27] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 11:05:28] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:05:29] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:05:29] PayPal\Core\PayPalHttpConnection : INFO: GET https://api.sandbox.paypal.com/v1/payments/payment/PAY-56U98642P13079828LBKRXKY
[17-12-2016 11:05:29] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:05:31] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:05:31] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment/PAY-56U98642P13079828LBKRXKY/execute
[17-12-2016 11:05:31] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:05:32] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 400
[17-12-2016 11:05:32] PayPal\Core\PayPalHttpConnection : ERROR: Got Http response code 400 when accessing https://api.sandbox.paypal.com/v1/payments/payment/PAY-56U98642P13079828LBKRXKY/execute. {"name":"PAYMENT_ALREADY_DONE","message":"Payment has been done already for this cart.","information_link":"https://developer.paypal.com/docs/api/#PAYMENT_ALREADY_DONE","debug_id":"ba09280a1727c"}
[17-12-2016 11:05:43] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 11:05:43] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:05:44] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:05:44] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 11:05:45] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:05:46] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 11:05:59] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 11:06:00] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:06:01] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:06:01] PayPal\Core\PayPalHttpConnection : INFO: GET https://api.sandbox.paypal.com/v1/payments/payment/PAY-8RY269458S066601MLBKRYCY
[17-12-2016 11:06:01] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:06:03] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:06:03] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment/PAY-8RY269458S066601MLBKRYCY/execute
[17-12-2016 11:06:03] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:06:05] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:06:24] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 11:06:24] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:06:25] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:06:25] PayPal\Core\PayPalHttpConnection : INFO: GET https://api.sandbox.paypal.com/v1/payments/payment/PAY-8RY269458S066601MLBKRYCY
[17-12-2016 11:06:26] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:06:27] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:06:27] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment/PAY-8RY269458S066601MLBKRYCY/execute
[17-12-2016 11:06:28] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:06:29] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 400
[17-12-2016 11:06:29] PayPal\Core\PayPalHttpConnection : ERROR: Got Http response code 400 when accessing https://api.sandbox.paypal.com/v1/payments/payment/PAY-8RY269458S066601MLBKRYCY/execute. {"name":"PAYMENT_ALREADY_DONE","message":"Payment has been done already for this cart.","information_link":"https://developer.paypal.com/docs/api/#PAYMENT_ALREADY_DONE","debug_id":"b65460086d0df"}
[17-12-2016 11:06:37] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 11:06:38] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:06:39] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:06:39] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 11:06:39] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:06:41] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 11:06:54] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 11:06:54] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:06:56] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:06:56] PayPal\Core\PayPalHttpConnection : INFO: GET https://api.sandbox.paypal.com/v1/payments/payment/PAY-26J6501713098160YLBKRYQI
[17-12-2016 11:06:56] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:06:57] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:06:57] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment/PAY-26J6501713098160YLBKRYQI/execute
[17-12-2016 11:06:58] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:06:59] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:41:05] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 11:41:06] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:41:07] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:41:07] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 11:41:08] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:41:09] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 11:41:25] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 11:41:25] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:41:27] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:41:27] PayPal\Core\PayPalHttpConnection : INFO: GET https://api.sandbox.paypal.com/v1/payments/payment/PAY-77L30705UX2116842LBKSIVI
[17-12-2016 11:41:27] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:41:28] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:41:28] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment/PAY-77L30705UX2116842LBKSIVI/execute
[17-12-2016 11:41:29] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:41:30] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:45:01] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 11:45:02] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:45:03] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:45:03] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 11:45:03] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:45:05] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 11:45:18] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 11:45:19] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:45:20] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:45:20] PayPal\Core\PayPalHttpConnection : INFO: GET https://api.sandbox.paypal.com/v1/payments/payment/PAY-03528821F97304127LBKSKQI
[17-12-2016 11:45:21] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:45:22] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:45:22] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment/PAY-03528821F97304127LBKSKQI/execute
[17-12-2016 11:45:22] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:45:24] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:45:52] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 11:45:53] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:45:54] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:45:54] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 11:45:54] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:45:56] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 11:48:50] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 11:48:51] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:48:52] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:48:52] PayPal\Core\PayPalHttpConnection : INFO: GET https://api.sandbox.paypal.com/v1/payments/payment/PAY-28Y64635JU9293711LBKSK5A
[17-12-2016 11:48:52] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:48:54] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:48:54] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment/PAY-28Y64635JU9293711LBKSK5A/execute
[17-12-2016 11:48:54] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:48:58] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:49:36] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 11:49:37] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:49:38] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:49:38] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 11:49:38] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:49:40] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 11:50:03] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 11:50:03] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:50:04] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:50:04] PayPal\Core\PayPalHttpConnection : INFO: GET https://api.sandbox.paypal.com/v1/payments/payment/PAY-39X56047VY8578917LBKSMVA
[17-12-2016 11:50:05] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:50:06] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 11:50:06] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment/PAY-39X56047VY8578917LBKSMVA/execute
[17-12-2016 11:50:06] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 11:50:08] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 01:41:51] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 01:41:52] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 01:41:53] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 01:41:53] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 01:41:54] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 01:41:55] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 201
[17-12-2016 01:42:23] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 01:42:23] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 01:42:24] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 01:42:24] PayPal\Core\PayPalHttpConnection : INFO: GET https://api.sandbox.paypal.com/v1/payments/payment/PAY-5DH63736F1042400PLBKUBIY
[17-12-2016 01:42:25] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 01:42:26] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 01:42:26] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment/PAY-5DH63736F1042400PLBKUBIY/execute
[17-12-2016 01:42:27] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 01:42:29] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 01:44:20] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[17-12-2016 01:44:21] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 01:44:25] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[17-12-2016 01:44:25] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[17-12-2016 01:44:25] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[17-12-2016 01:44:26] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 400
[17-12-2016 01:44:26] PayPal\Core\PayPalHttpConnection : ERROR: Got Http response code 400 when accessing https://api.sandbox.paypal.com/v1/payments/payment. {"name":"VALIDATION_ERROR","details":[{"field":"transactions[0].amount","issue":"Amount cannot be zero"}],"message":"Invalid request - see details","information_link":"https://developer.paypal.com/docs/api/#VALIDATION_ERROR","debug_id":"92dca97b13e62"}
[18-12-2016 08:33:07] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[18-12-2016 08:33:08] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[18-12-2016 08:33:09] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[18-12-2016 08:33:09] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[18-12-2016 08:33:09] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[18-12-2016 08:33:10] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 400
[18-12-2016 08:33:10] PayPal\Core\PayPalHttpConnection : ERROR: Got Http response code 400 when accessing https://api.sandbox.paypal.com/v1/payments/payment. {"name":"VALIDATION_ERROR","details":[{"field":"transactions[0].amount","issue":"Amount cannot be zero"}],"message":"Invalid request - see details","information_link":"https://developer.paypal.com/docs/api/#VALIDATION_ERROR","debug_id":"9e985274abf56"}
[18-12-2016 08:33:23] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[18-12-2016 08:33:24] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[18-12-2016 08:33:25] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[18-12-2016 08:33:25] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[18-12-2016 08:33:26] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[18-12-2016 08:33:27] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 400
[18-12-2016 08:33:27] PayPal\Core\PayPalHttpConnection : ERROR: Got Http response code 400 when accessing https://api.sandbox.paypal.com/v1/payments/payment. {"name":"VALIDATION_ERROR","details":[{"field":"transactions[0].amount","issue":"Amount cannot be zero"}],"message":"Invalid request - see details","information_link":"https://developer.paypal.com/docs/api/#VALIDATION_ERROR","debug_id":"78f02098424ad"}
[18-12-2016 08:33:36] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[18-12-2016 08:33:37] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[18-12-2016 08:33:37] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[18-12-2016 08:33:38] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[18-12-2016 08:33:38] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[18-12-2016 08:33:39] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 400
[18-12-2016 08:33:39] PayPal\Core\PayPalHttpConnection : ERROR: Got Http response code 400 when accessing https://api.sandbox.paypal.com/v1/payments/payment. {"name":"VALIDATION_ERROR","details":[{"field":"transactions[0].amount","issue":"Amount cannot be zero"}],"message":"Invalid request - see details","information_link":"https://developer.paypal.com/docs/api/#VALIDATION_ERROR","debug_id":"2dd74c6c796df"}
[18-12-2016 09:07:26] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[18-12-2016 09:07:27] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[18-12-2016 09:07:28] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[18-12-2016 09:07:28] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[18-12-2016 09:07:29] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[18-12-2016 09:07:30] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 400
[18-12-2016 09:07:30] PayPal\Core\PayPalHttpConnection : ERROR: Got Http response code 400 when accessing https://api.sandbox.paypal.com/v1/payments/payment. {"name":"VALIDATION_ERROR","details":[{"field":"transactions[0].amount","issue":"Amount cannot be zero"}],"message":"Invalid request - see details","information_link":"https://developer.paypal.com/docs/api/#VALIDATION_ERROR","debug_id":"a79798a63bc44"}
[26-12-2016 04:45:16] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[26-12-2016 04:45:17] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[26-12-2016 04:45:19] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[26-12-2016 04:45:19] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[26-12-2016 04:45:20] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[26-12-2016 04:45:22] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 400
[26-12-2016 04:45:22] PayPal\Core\PayPalHttpConnection : ERROR: Got Http response code 400 when accessing https://api.sandbox.paypal.com/v1/payments/payment. {"name":"VALIDATION_ERROR","details":[{"field":"transactions[0].amount","issue":"Amount cannot be zero"}],"message":"Invalid request - see details","information_link":"https://developer.paypal.com/docs/api/#VALIDATION_ERROR","debug_id":"5d1d0fa3fda4"}
[26-12-2016 04:49:57] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/oauth2/token
[26-12-2016 04:49:58] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[26-12-2016 04:50:00] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 200
[26-12-2016 04:50:00] PayPal\Core\PayPalHttpConnection : INFO: POST https://api.sandbox.paypal.com/v1/payments/payment
[26-12-2016 04:50:01] PayPal\Core\PayPalHttpConnection : INFO: Invalid or no certificate authority found - Retrying using bundled CA certs file
[26-12-2016 04:50:04] PayPal\Core\PayPalHttpConnection : INFO: Response Status 	: 400
[26-12-2016 04:50:04] PayPal\Core\PayPalHttpConnection : ERROR: Got Http response code 400 when accessing https://api.sandbox.paypal.com/v1/payments/payment. {"name":"VALIDATION_ERROR","details":[{"field":"transactions[0].amount","issue":"Amount cannot be zero"}],"message":"Invalid request - see details","information_link":"https://developer.paypal.com/docs/api/#VALIDATION_ERROR","debug_id":"bc52bfd643f"}
